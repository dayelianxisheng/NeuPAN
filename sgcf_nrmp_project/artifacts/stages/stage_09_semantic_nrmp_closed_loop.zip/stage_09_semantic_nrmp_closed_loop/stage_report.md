# Stage 09 Final Stage Report

## Final Status

```text
STAGE_09_COMPLETE
SEMANTIC_NRMP_VALIDATED
READY_FOR_STAGE_10
```

Stage 09 revalidation is accepted. The exact observable-geometry planner remains
the unchanged safety foundation, while a bounded nonnegative semantic margin is
added to its constraint right-hand side. No Stage 10 implementation is included.

## Accepted Evidence

- P0 and Stage 05 are exactly equivalent over the synchronized audit cycles:
  planner-status differences and maximum absolute control, state, distance,
  gradient, and slack errors are all zero.
- Corrected empty scenes have zero geometry rejection, solver timeout, and
  observable collision. Superseded empty-scene results are not blockers.
- The intentional initial-collision case is classified as `initial_collision`
  and returns `EMERGENCY_STOP`; it is not a planner-induced collision.
- For the HUMAN case, minimum observable clearance changes from
  `0.3027139313 m` in P0 to `0.5978830647 m` in P1/P2.
- For the STATIC case, P0/P1/P2 remain exactly `0.3027139313 m`.
- Under RGB dropout and an outdated image, P2 controls are elementwise identical
  to P0. This proves deterministic geometry-only degradation for those explicit
  failures; it does not prove silent calibration-error detection.
- Semantic margins remain within the accepted numerical interval
  `0 <= semantic_margin <= 0.35 m` (the stored floating-point maximum is
  `0.3500000000000001 m`).
- Online planning does not consume world geometry. Equal online observations
  with different hidden worlds produce identical controls; complete-world
  geometry is used only after control selection for offline evaluation.

## Collision Accounting

Across the three evaluated Stage 09 planner modes in the intentional collision
fixture:

```text
initial_collision_count: 3
correct_emergency_stop_count: 3
planner_induced_collision_count: 0
trajectory_collision_count: 3
```

The three trajectory collisions are the already-colliding initial state, not
collisions caused by an executed planner action. In initially safe normal
planning scenarios, planner-induced observable collision is zero.

## Latency Interpretation

Latency is reported in three non-interchangeable categories:

1. one-time planner initialization;
2. first-cycle CVXPY canonicalization/OSQP setup;
3. steady-state online cycles.

The retained `online_p95_max_ms = 179.09349700494204` is a
**first-cycle / setup-inclusive peak**, not the steady-state acceptance metric.
No slow sample was deleted. Each deterministic record retains first-cycle,
steady-state mean, P50, P95, and P99 values in `latency_breakdown.json`.

The maximum named-scenario steady-state online-equivalent P95 is
`63.21148740025818 ms`, therefore the formal result is:

```text
steady-state online-equivalent P95 < 100 ms
```

Deployment must prewarm or persist the solver because setup-inclusive first
cycles can be materially slower than steady state.

## Decision

All twelve final acceptance checks pass: Stage 05/P0 equality, corrected empty
scenes, collision classification and stop behavior, zero normal planner-induced
collision, HUMAN widening, unchanged STATIC behavior, explicit-failure
degradation, bounded margins, no online world access, hidden-world control
invariance, steady-state P95 below 100 ms, and no protected-directory increment.

The formal decision is `SEMANTIC_NRMP_VALIDATED`.

The comprehensive final narrative is in `stage_09_final_report.md`; limitations
remain binding in `known_limitations.md`.
