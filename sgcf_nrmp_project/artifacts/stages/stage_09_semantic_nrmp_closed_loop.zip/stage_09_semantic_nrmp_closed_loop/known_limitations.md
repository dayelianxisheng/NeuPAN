# Stage 09 Known Limitations

Status: `STAGE_09_COMPLETE` / `SEMANTIC_NRMP_VALIDATED`

1. Semantics are supplied by an Oracle semantic map and Hard PointPainting, not
   by a real RGB perception network.
2. The R1 Gate handles only explicit failures: missing RGB, outdated images,
   invalid projection, and `UNKNOWN` semantics.
3. A single online frame cannot identify silent extrinsic-calibration drift.
   The current operating assumption is `CALIBRATION_ASSUMED_VALID`.
4. Stage 09 studies static or instantaneous semantic obstacles. It does not
   predict future HUMAN or VEHICLE motion.
5. World geometry is available only to offline evaluation and is not a planner
   input.
6. Semantic constraints add behavioral clearance margins; they do not replace
   exact observable-geometry safety.
7. First-cycle canonicalization/solver setup is slower than steady state.
   Deployment requires solver persistence or prewarming.
8. The result does not establish formal safety guarantees, real-RGB validity,
   silent-calibration detection, or dynamic-agent prediction.

The formerly reported empty-scene fixture error was corrected and is not a
current limitation or Stage 10 blocker.
